
X = zeros(128, 24, 24);
Y = zeros(128, 1);
load ('/home/yin/disk3/exoskeleton/subject12_run1_cov.mat');
X(1:32, :, :) = fea;
Y(1:32, 1) = gnd';
load ('/home/yin/disk3/exoskeleton/subject12_run2_cov.mat');
X(33:64, :, :) = fea;
Y(33:64, 1) = gnd';
load ('/home/yin/disk3/exoskeleton/subject12_run3_cov.mat');
X(65:96, :, :) = fea;
Y(65:96, 1) = gnd';
load ('/home/yin/disk3/exoskeleton/subject12_run4_cov.mat');
X(97:128, :, :) = fea;
Y(97:128, 1) = gnd';
load ('/home/yin/disk3/exoskeleton/subject12_run5_cov.mat');
X(129:160, :, :) = fea;
Y(129:160, 1) = gnd';

clear fea gnd
save /home/yin/disk3/exoskeleton/subject12_cov.mat;

