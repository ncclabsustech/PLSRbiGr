
clear all
clc

addpath( genpath(pwd) );
Dataset_name = {'S001'};
%==========================================================================
nfactors = 4; % ע�� nfactors �������������

cross_num = 4;% k-CV
for iDB = 1:length( Dataset_name )% DB is data base; and length(DB) is number of Data Base.
    
    % load data
    TFBS_name = Dataset_name{ iDB };
    fprintf('Dataset Name:   %s\n', TFBS_name);
    fprintf('Loading   ...');
    %load( TFBS_name );% loading dataset
    
    load ('/home/yin/disk3/DATA_Fill/SSVEP_sub_011.mat');
    X = fea;
    Y = gnd';
    fprintf('Done\n');
    runtimes = 10; % runing 10 times
    for rn = 1 : runtimes
        % generates cross-validation indices
        indices = kFoldCV( Y, cross_num );% ���飬���뱣֤ÿһfold�а�������
        % indices = crossvalind('Kfold',length(yapp), cross_num);
        %     [train_indx,test_indx] = crossvalind('LeaveMOut',length(yapp))
        t1 = clock;% count time
        for cros = 1 : cross_num
            fprintf('Starting cross validation: %dth\n', cros );
            %=============== test dataset and train dataset =====================%
            test_indx = (indices == cros);
            train_indx = ~test_indx;
            
            train = X( train_indx, :);                     %===================%
            train_label = Y( train_indx );                     %      ѡ��ѵ����    %
            %                                                  %===================%
            
            test = X( test_indx, :);                       %===================%
            test_label = Y(test_indx);                         %     ѡ����Լ�     %
            %                                                  %===================%
            
            %==============================================================
            model = main_svdmanifold( train, train_label, nfactors);
           %% predicting
            disp('Testing')
            pred = predict( test, model );
            results.time(rn, cros) = model.time;
            results.cv(rn,cros) = classperfchr( pred{nfactors}.class_pred, test_label );
        end
        results.runingtime = etime(clock,t1)/cross_num;
        results.indices_cv{rn} = indices;
        clear train;  
    end
    for rn = 1 : runtimes
        F = 0;
        for cros = 1 : cross_num
            F = F + results.cv(rn,cros).F_measure;
        end
        F_measure( rn ) = F/cross_num;
    end
    results.F_measure = F_measure;
    results.avgF = sum(F_measure)/rn;
    results.stdF = std( F_measure );
    %%%%%%%%%%%%%%%%%%%%%%
    for rn = 1 : runtimes
        AC = 0;
        for cros = 1 : cross_num
            AC = AC + results.cv(rn,cros).accuracy;
        end
        accuracy( rn ) = AC/cross_num;
    end
    results.accuracy = accuracy;
    results.avgAC = sum(accuracy)/rn;
    results.stdAC = std( accuracy );
    %%%%%%%%%%%%%% Precision %%
    for rn = 1 : runtimes
        Pr = 0;
        for cros = 1 : cross_num
            Pr = Pr + results.cv(rn,cros).Precision;
        end
        Precision( rn ) = Pr/cross_num;
    end
    results.Precision = Precision;
    results.avgPr = sum(Precision)/rn;
    results.stdPr = std( Precision );
    %%%%%%%%%% Recall %%%%%%%%
    for rn = 1 : runtimes
        Re = 0;
        for cros = 1 : cross_num
            Re = Re + results.cv(rn,cros).Recall;
        end
        Recall( rn ) = Re/cross_num;
    end
    results.Recall = Recall;
    results.avgRe = sum(Recall)/rn;
    results.stdRe = std( Recall );
    %%%%%%%%%% Time %%%%%%%%%
    for rn = 1 : runtimes
        Ti = 0;
        for cros = 1 : cross_num
            Ti = Ti + results.time(rn,cros);
        end
        Time( rn ) = Ti/cross_num;
    end
    results.Time = Time;
    results.avgTi = sum(Time)/rn;
    results.stdTi = std( Time );
    
    %results.numPos = num_class(1);
    save(['results/','res_', 'svdmanifold_', TFBS_name ],  'results'); 
    clear results
    figure(1)
    title('# Visualization');
    P = tsne(pred{nfactors}.yc);
    label = pred{nfactors}.class_pred;
    gscatter(P(:,1), P(:,2), label);
    figure(2)
    title('# Visualization');
    P = tsne(test);
    label = test_label;
    gscatter(P(:,1), P(:,2), label);
    
end
    

