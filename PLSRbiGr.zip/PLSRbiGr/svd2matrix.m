function Xmatrix = svd2matrix(X)
% Converts a 3d Tucker form tensor to a multiarray.
%
% function Xtensor = tucker2multiarray(X)
%
% X has fields U1, U2, U3, and G.
%
% The matrices U1 (n1-by-r1), U2 (n2-by-r2) and U3 (n3-by-r3) are
% orthogonal matrices.
% G (r1-by-r2-by-r3) is a multidimensional array.
%
% See also: fixedrankfactory_tucker_preconditioned

% This file is part of Manopt: www.manopt.org.
% Original authors: Hiroyuki Kasai and Bamdev Mishra, June 05, 2015.
% Contributors:
% Change log:
    U = X.U;
    V = X.V;
    S = X.S;
    
    Xmatrix = U*S*V';% Full tensor
    
end
