function [Us] = Riemannian_tensor222factor(Z, lowerdims)
sizeZ = size(Z);
nmodes = length(sizeZ);
Us = cell(1, nmodes);
for kmode = 1:nmodes
    Us{kmode} = orth(randn(sizeZ(kmode), lowerdims(kmode)))/1000;
    
end

U.U1 = Us{1};
U.U2 = Us{2};
U.U3 = Us{3};


tuple.U1 = obliquefactory(size(Us{1}, 1), size(Us{1}, 2));
tuple.U2 = obliquefactory(size(Us{2}, 1), size(Us{2}, 2));
tuple.U3 = obliquefactory(size(Us{3}, 1), size(Us{3}, 2));
manifold = productmanifold(tuple);
problem.M = manifold;

problem.cost  = @(U, store) mycost(U, store, Z);
        
problem.egrad = @(U, store) mygrad(U, store, Z);

maxits = 1000;
options.intialtau = -1;
options.mxitr = maxits;
options.record = 1;
options.maxiter = maxits;
        
[U, ~, ~] = conjugategradient(problem, U, options);
Us{1} = U.U1;
Us{2} = U.U2;
Us{3} = U.U3;

end

function [F, store] = mycost(U, store, Z)
F = ttm(ttm(ttm(Z, U.U1', 1), U.U2', 2), U.U3', 3);
F = - trace(double(tenmat(F, 1)) * double(tenmat(F, 1))');
store.F = F;
end


function [G, store] = mygrad(U, store, Z)

G.U1 = -2 *double(tenmat(Z, 1)) * double(tenmat(Z, 1))' *U.U1;
G.U2 = -2 *double(tenmat(Z, 2)) * double(tenmat(Z, 2))' * U.U2;
G.U3 = -2 *double(tenmat(Z, 3)) * double(tenmat(Z, 3))' * U.U3;
store.G = G;
end




