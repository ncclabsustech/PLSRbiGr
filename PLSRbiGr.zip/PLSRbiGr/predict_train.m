function thr = predict_train( Xtrain, R, nfactor)

%% preprocessing
%%
Wtpls = R ;

Xnew = Xtrain;

for nfac = 1:nfactor
    
    Yp = Xnew * Wtpls{ nfac };%
    
    %% results for predict
    thr = hoplscfindthr( Yp, y_true );
end