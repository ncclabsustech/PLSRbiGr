function M = svdmanifold_noscaling( matrix_size )
% Manifold of fixed multilinear rank tensors in Tucker format.
%
% function M = fixedrankfactory_tucker_preconditioned(tensor_size, tensor_rank)
%
% n1 = tensor_size(1);
% n2 = tensor_size(2);
% n3 = tensor_size(3);
% r1 = tensor_rank(1);
% r2 = tensor_rank(2);
% r3 = tensor_rank(3);
%
% A point X on the manifold is represented as a structure with four
% fields: U1, U2, U3 and G. The matrices U1 (n1-by-r1), U2 (n2-by-r2),
% and U3 (n3-by-r3) are orthogonal matrices. G (r1-by-r2-by-r3) is a 
% multidimensional array.
%
% Tangent vectors are represented as a structure with four fields: 
% U1, U2, U3, and G.
%
% We exploit the quotient nature of Tucker decompositions to impose a
% scaled inner product on the manifold. This suits least-squares problems.
% For details, refer to the technical report:
% "{R}iemannian preconditioning for tensor completion",
% H. Kasai and B. Mishra, Arxiv preprint arXiv:1506.02159, 2015.
%
% Paper link: http://arxiv.org/abs/1506.02159.
%
% Please cite the Manopt paper as well as the research paper:
%     @TechReport{kasai2015precon,
%       Title   = {{R}iemannian preconditioning for tensor completion},
%       Author  = {Kasai, H. and Mishra, B.},
%       Journal = {Arxiv preprint arXiv:1506.02159},
%       Year    = {2015}
%     }

% Original authors: Hiroyuki Kasai and Bamdev Mishra, June 5, 2015.
% Contributors: 
% Change log:

    if length(matrix_size) > 2
        error('Bad usage of fixedrankfactory_tucker_preconditioned. Currently, only handles 3-order tensors.');
    end
    
    % matrix size
    m = matrix_size(1);
    n = matrix_size(2);
    r = min(m,n);
    

    M.name = @() sprintf('S x U x V  quotient SVD manifold of %d-by-%d matrix.', m, n);
    
    M.dim = @() m*r-r^2 + n*r-r^2 + r^2 ;
    
    % Some precomputations at point X to be used in the inner product (and
    % pretty much everywhere else)
    function X = prepare(X)
        if ~all(isfield(X,{'SSt',...
                'StS'}) == 1)
            X.SSt = X.S*X.S'; % Positive definite
            X.StS = X.S'*X.S; % Positive definite 
            
        end
        
    end
    
    % Choice of metric is motivated by symmetry and tuned to least-squares
    % cost function
    M.inner = @iproduct;
    function ip = iproduct(X, eta, zeta)
        X = prepare(X);
        ip =  trace(eta.U'*zeta.U) ...
            + trace(eta.V'*zeta.V) + trace(eta.S'*zeta.S);
    end
    M.norm = @(X, eta) sqrt(M.inner(X, eta, eta));
    
    M.dist = @(x, y) error('SVD manifold dist not implemented yet.');
    
    M.typicaldist = @() 10*n*r; % BM: To do  
    
    skew = @(X) .5*(X-X');
    symm = @(X) .5*(X+X');
    
    M.egrad2rgrad = @egrad2rgrad;
    function rgrad = egrad2rgrad(X, egrad)
        X = prepare(X); % Reuse already computed terms
        
        SSU = X.SSt;
        ASU = 2*symm(SSU*(X.U' * egrad.U));
        
        SSV = X.StS;
        ASV = 2*symm(SSV*(X.V' * egrad.V));
        
        BU = lyap(SSU, -ASU);
        BV = lyap(SSV, -ASV);
        
        % The lyap solutions ensure that the Riemannian gradient rgrad 
        % is now on the tangent space. From the Riemannian submersion 
        % theory, it also belongs to the horizontal space. Therefore,
        % no need to further project it on the horizontal space.
        
        rgrad.U = (egrad.U - X.U*BU);
        rgrad.V = (egrad.V - X.V*BV);
        rgrad.S = egrad.S;
        
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    M.ehess2rhess = @ehess2rhess;
    function Hess = ehess2rhess(X, egrad, ehess, eta)
        X = prepare(X); % Reuse already computed terms
        
        SSU = X.SSt;
        ASU = 2*symm(SSU*(X.U' * egrad.U));
        
        SSV = X.StS;
        ASV = 2*symm(SSV*(X.V' * egrad.V));
        
       
        BU = lyap(SSU, -ASU);
        BV = lyap(SSV, -ASV);
        
        rgrad.U = (egrad.U - X.U*BU)/X.SSt;
        rgrad.V = (egrad.V - X.V*BV)/X.StS;
        rgrad.S = egrad.S;
        % =================================================================
        % =================================================================
        % Directional derivative of the Riemannian gradient.
        ASUdot = 2*symm((2*symm(X.S*eta.S')*(egrad.S*X.S')) + X.SSt*(ehess.S*X.S' + egrad.S*eta.S')) - 4*symm(symm(eta.S*X.S')*BU);
        ASVdot = 2*symm((2*symm(X.S'*eta.S)*(egrad.S'*X.S)) + X.StS*(ehess.S'*X.S + egrad.S'*eta.S)) - 4*symm(symm(eta.S'*X.S)*BV);
        
        BUdot = lyap(SSU, -ASUdot);
        BVdot = lyap(SSV, -ASVdot);
        
        Hess.U = (ehess.U - eta.U*BU - X.U*BUdot - 2*rgrad.U*symm(eta.S*X.S'))/X.SSt;
        Hess.V = (ehess.V - eta.V*BV - X.V*BVdot - 2*rgrad.V*symm(eta.S'*X.S))/X.StS;
        Hess.S = ehess.S;
        % The computation of the correction factor owes itself to the Koszul formula.
        % This corresponds to the Riemannian connection in the Euclidean space with the
        % scaled metric.
        Hess.U = Hess.U + (eta.U*symm(Hess.S*X.S') + rgrad.U*symm(eta.S*X.S'))/X.SSt;
        Hess.V = Hess.V + (eta.V*symm(Hess.S'*X.S) + rgrad.V*symm(eta.S'*X.S))/X.StS;
        
        
        
        Hess = M.proj(X, Hess);
        
    end

    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 
 
 
 
    M.proj = @projection;
    function etaproj = projection(X, eta)
        X = prepare(X); % Reuse already computed terms
        X.SSt = X.S*X.S';
        X.StS = X.S'*X.S;
        % First, projection onto tangent space of total space
        SSU = X.SSt;
        ASU = 2*symm(X.SSt*(X.U'*eta.U )*X.SSt);
        BU = lyap(SSU, -ASU);
        eta.U = eta.U - X.U*(BU/X.SSt);
        
        SSV = X.StS;
        ASV = 2*symm(X.StS*(X.V'*eta.V)*X.StS);
        BV = lyap(SSV, -ASV);
        eta.V = eta.V - X.V*(BV/X.StS);
        eta.S = eta.S;
        
        
        % Project onto the horizontal space.
        % =================================================================
        SSU = X.SSt;
        ASU = 2*skew(X.U'*eta.U*X.SSt);
        BU = lyap(SSU, -ASU);
        etaproj.U = eta.U - X.U*BU;
        
        SSV = X.StS;
        ASV = 2*skew(X.V'*eta.V*X.StS);
        BV = lyap(SSV, -ASV);
        etaproj.V = eta.V - X.V*BV;
        etaproj.S = eta.S;
        
    end
    
    
    
    M.tangent = M.proj;
    M.tangent2ambient = @(X, eta) eta;
    
    M.retr = @retraction;
    function Y = retraction(X, eta, t)
        if nargin < 3
            t = 1.0;
        end
        
        Y.U = uf((X.U + t*eta.U)); % U factor of Polar factorization
        Y.V = uf((X.V + t*eta.V));
        Y.S = (X.S + t*eta.S);
        Y = prepare(Y);
    end
    
    M.exp = @exponential;
    function Y = exponential(X, eta, t)
        if nargin < 3
            t = 1.0;
        end
        Y = retraction(X, eta, t);
        warning('manopt:fixedrankfactory_tucker_preconditioned:exp', ...
            ['Exponential for fixed rank ' ...
            'Tucker manifold not implemented yet. Used retraction instead.']);
    end
    
    M.hash = @(X) ['z' hashmd5([sum(X.U(:)) ; sum(X.V(:)) ; sum(X.S(:))])]; % Efficient, suggested by Bart Vandereycken.
    % M.hash = @(X) ['z' hashmd5([X.U1(:); X.U2(:)])];
    
    M.rand = @random;
    function X = random()
        %         % Random generator on the total space
        %         % FactorsU2, and U3 are on Stiefel manifolds, hence we reuse
        %         % their random generator.
        %         stiefelm = stiefelfactory(n2, r2);
        %         stiefeln = stiefelfactory(n3, r3);
        %
        %         X.U2 = stiefelm.rand();
        %         X.U3 = stiefeln.rand();
        %
        %         % Random initialization: generalization of randn(r1, r1 = r2) in the
        %         % matrix case.
        %         X.G = randn(n,r2,r3);
        
        
        %  Random generator on the fixed-rank space from a uniform distribution on [0, 1].
        %[U, S, V] = svd(rand(m, n), 'econ');
        [U, S, V] = svds(rand(m, n), r);
        X.U = U;
        X.V = V;
        X.S = S;
    
        % Compute some terms that are used subsequently.
        X = prepare(X);
        
    end
    

    M.randvec = @randomvec;
    function eta = randomvec(X)
        % A random vector on the horizontal space
        eta.U = randn(m, r);
        eta.V = randn(n, r);
        eta.S = diag(diag(rand(r,r)));
        eta = projection(X, eta);
        nrm = M.norm(X, eta);
        eta.U = eta.U / nrm;
        eta.V = eta.V / nrm;
        eta.S = eta.S / nrm;
    end

    M.lincomb = @lincomb;
    
    M.zerovec = @(X) struct('U', zeros(m, r), 'V', zeros(n, r), 'S', zeros(r, r));    
    M.transp = @(x1, x2, d) projection(x2, d);
    
    % vec and mat are not isometries, because of the scaled metric.
    M.vec = @(X, U) [U.U(:); U.V(:); U.S(:)];
    M.vecmatareisometries = @() false;
    
end

% Linear combination of tangent vectors
function d = lincomb(X, a1, d1, a2, d2) %#ok<INUSL>
    
    if nargin == 3
        d.U = a1*d1.U;
        d.V = a1*d1.V;
        d.S = a1*d1.S;
    elseif nargin == 5
        d.U = a1*d1.U + a2*d2.U;
        d.V = a1*d1.V + a2*d2.V;
        d.S = a1*d1.S + a2*d2.S;
    else
        error('Bad use of fixedrankfactory_tucker_preconditioned.lincomb.');
    end
    
end

function U = uf(A) % U factor of Polar factorization of a tall matrix A.
    [L, unused, R] = svd(A, 0); %#ok
    U = L*R';
end