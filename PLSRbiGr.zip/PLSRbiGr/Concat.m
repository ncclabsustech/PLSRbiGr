function T = Concat(A, B, n)
    % Ui is a list of n 3-order tensor
    % T  is a tensor of order n+2 after merging Ui
    A = tenmat(A, n);
    B = tenmat(B, n);
    T = A*B';
end
