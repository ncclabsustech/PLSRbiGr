function YY = binarize_y( Y )
% function - encodes class membership in binary form
% G - the total number of classes

unics = unique( Y );
G = length( unics );

YY = zeros(length(Y), G );

for g = 1 : G
    YY( find( Y==unics( g ) ), g ) = 1;
end
end