function model = main_Tuckermanifold( train, train_label, nfactors)
% =========================================================================
            tensor_rank = [nfactors, 32, 32];
            n = size(train, 1);
            y_label = binarize_y( train_label );
            % 去中心化 ====================================================
            % =============================================================
            mean_train = mean(train,1);
            train = bsxfun(@minus, train, mean_train);
            mean_label = mean(y_label,1);
            y_label = bsxfun(@minus, y_label, mean_label);
            % =============================================================
            Z = tensor(reshape(train, n, 32, 32));
            Z = ttm(Z, y_label', 1);
            
            Xtr = tensor_Tuckermanifold( Z, tensor_rank );
            W = kron(Xtr.U2, Xtr.U3);
            % =============================================================
            % =============================================================
            T = train*W;
            T = T/norm(T);
            U = y_label*Xtr.U1;
            G = ttm(ttm(ttm(Z, Xtr.U1', 1), Xtr.U2', 2), Xtr.U3', 3);
            G = double(tenmat(G, 1));
            D = G'*G;
            %D = U'*T;
            P = train'*T;
            Q = y_label'*T;
            % =============================================================
            for i = 1:nfactors
                Wstar{ i } = W(:, 1:i ) * pinv( (P(:, 1:i )'*W( :, 1:i ) +  diag(rand(i,1))*eps ) );
                R{ i } = Wstar{ i } *D(i, i)* Q(:, 1:i )';
            end
            % =============================================================
            Ypred = train * R{nfactors};
            if abs(min( Ypred(:,1) ) - max( Ypred(:,1) ))<eps | abs(min( Ypred(:,2) ) - max( Ypred(:,2) ))<eps
                disp('wait');
            end
            resthr = hoplscfindthr( Ypred, train_label );
            % =============================================================
            model.yc = Ypred;
            model.thr = resthr.class_thr;
            model.Wstar = Wstar;
            model.R = R;
            model.nfactors = nfactors;

end

