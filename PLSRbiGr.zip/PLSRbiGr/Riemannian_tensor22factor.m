
function [Us] = Riemannian_tensor22factor(Z, lowerdims)
sizeZ = size(Z);
nmodes = length(sizeZ);
Us = cell(1, nmodes);
for kmode = 1:nmodes
    Us{kmode} = orth(randn(sizeZ(kmode), lowerdims(kmode)));
    
end

U.U1 = Us{1};
U.U2 = Us{2};
U.U3 = Us{3};


tuple.U1 = stiefelfactory(size(Us{1}, 1), size(Us{1}, 2));
tuple.U2 = stiefelfactory(size(Us{2}, 1), size(Us{2}, 2));
tuple.U3 = stiefelfactory(size(Us{3}, 1), size(Us{3}, 2));
manifold = productmanifold(tuple);
problem.M = manifold;

problem.cost  = @(U, store) mycost(U, store, Z);
        
problem.egrad = @(U, store) mygrad(U, store, Z);
problem.hess = @(U, store) myhess(U, store, Z);

% options
options.maxiter = 200;
options.maxinner = 30;
options.maxtime = inf;
options.tolgradnorm = 1e-5;
options.Delta_bar = problem.M.typicaldist();
 % Minimize the cost function using Riemannian trust-regions
 U = trustregions(problem, [], options);
 
 Us{1} = U.U1;
 Us{2} = U.U2;
 Us{3} = U.U3;

end

function [F, store] = mycost(U, store, Z)
F = ttm(ttm(ttm(Z, U.U1', 1), U.U2', 2), U.U3', 3);
F = - trace(double(tenmat(F, 1)) * double(tenmat(F, 1))');
store.F = F;
end


function [G, store] = mygrad(U, store, Z)

G.U1 = -2 *double(tenmat(Z, 1)) * double(tenmat(Z, 1))' *U.U1;
G.U2 = -2 *double(tenmat(Z, 2)) * double(tenmat(Z, 2))' * U.U2;
G.U3 = -2 *double(tenmat(Z, 3)) * double(tenmat(Z, 3))' * U.U3;
G = problem.M.egrad2rgrad(U, G);
store.G = G;
end

function [H, store] = myhess(U, store, Z, eta)

H.U1 = -2 *double(tenmat(Z, 1)) * double(tenmat(Z, 1))' *eta.U1;
H.U2 = -2 *double(tenmat(Z, 2)) * double(tenmat(Z, 2))' * eta.U2;
H.U3 = -2 *double(tenmat(Z, 3)) * double(tenmat(Z, 3))' * eta.U3;
H = problem.M.ehess2rhess(U, store.G, H, eta) ;
store.H = H;
end

