
function [model, Us, D] = Riemannian_HOPLSR( train, train_label, nfactors)
n = size(train, 1);
if size(train_label, 2) == 1
    y_label = binarize_y(train_label);
end
mean_train = mean(train,1);
train = bsxfun(@minus, train, mean_train);
mean_label = mean(y_label,1);
y_label = bsxfun(@minus, y_label, mean_label);
X = tensor(reshape(train, [n 24 401]));


Z = ttm(X, y_label', 1);
[Us] = Riemannian_tensor2factor(Z);
W = kron(Us{2}, Us{3});
%W = khatrirao(Us{2},Us{3});
T = train*W;
T = T/norm(T);
%U = y_label*Us{1};
G = ttm(ttm(ttm(Z, Us{1}', 1), Us{2}', 2), Us{3}', 3);
G = double(tenmat(G, 1));
D = G'*G;
disp(size(D));
%D = U'*T;
P = train'*T;
Q = y_label'*T;
disp(size(Q));
% =============================================================
for i = 1:nfactors
    Wstar{ i } = W(:, 1:i ) * pinv( (P(:, 1:i )'*W( :, 1:i ) +  diag(rand(i,1))*eps ) );
    R{ i } = Wstar{ i } *D(i, i)* Q(:, 1:i )';
end
% =============================================================
Ypred = train * R{nfactors};
 if abs(min( Ypred(:,1) ) - max( Ypred(:,1) ))<eps | abs(min( Ypred(:,2) ) - max( Ypred(:,2) ))<eps
     disp('wait');
 end
 resthr = hoplscfindthr( Ypred, train_label );
 % =============================================================
 model.yc = Ypred;
 model.thr = resthr.class_thr;
 model.Wstar = Wstar;
 model.R = R;
 model.nfactors = nfactors;


end


function YY = binarize_y(Y)
unumber = unique(Y);
C = length(unumber);
YY = zeros(length(Y), C);
for c = 1:C
    YY ( find(Y == unumber(c)), c) = 1;
end
    
end


