function model = main_kernelPLS( train, train_label, nfactors)
% =========================================================================
            y_label = binarize_y( train_label );
            % ȥ���Ļ� =====================================================
            % =============================================================
            %mean_train = mean(train,1);
            %train = bsxfun(@minus, train, mean_train);
            %mean_label = mean(y_label,1);
            %y_label = bsxfun(@minus, y_label, mean_label);
            % =============================================================
            [R, Ypred] = kernel_PLS( train, y_label, nfactors );
            
            if abs(min( Ypred(:,1) ) - max( Ypred(:,1) ))<eps | abs(min( Ypred(:,2) ) - max( Ypred(:,2) ))<eps
                disp('wait');
            end
            resthr = hoplscfindthr( Ypred, train_label );
            % =============================================================
            model.yc = Ypred;
            model.thr = resthr.class_thr;
            model.R = R;
            model.nfactors = nfactors;

end