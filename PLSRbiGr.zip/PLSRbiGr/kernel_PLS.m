function [R, Ypred] = kernel_PLS( X, Y, nfactors )
alpha = 1;                             %  parameter setting  %
coef = 0.1;                            %---------------------%
K = kernel( X, X, 'polynomial', alpha, coef );                 %  polynomial kernel  %
Kx = kernel( X, X([1:2:size(X,1)], : ), 'polynomial', alpha, coef );
% =========================================================================
% ============== centralize the kernel K matrix ===========================
%n = size(X, 1);
%I = ones(n, n);
%II = ones(n, 1)*ones(n, 1)';
%K = (I - (1/n)*II)*K*(I - (1/n)*II);
% =========================================================================
Kres = K; Yres = Y;
R = cell(1, nfactors);
for i=1:nfactors
    YYK = Yres*Yres'*Kres;
    U(:,i) = Yres(:,1)/norm(Yres(:,1));
    if size(Yres,2) > 1 % only loop if dimension greater than 1
        bold = U(:,i) + 1;
        while norm(U(:,i) - bold) > 0.001
            bold = U(:,i);
            tw = YYK*U(:,i);
            W(:,i) = tw/norm(tw);
        end
    end
    T(:,i) = Kres*U(:,i); % T = T(:,i)/norm(T(:,i));Ч����
    normT = T(:,i)'*T(:,i);
    Q(:,i) = Yres'*T(:,i)/normT;
    U(:,i) = U(:,i)/normT;
    %====================================
    p = Kres*T(:,i)/normT;
    Kres = Kres - T(:,i)*p' - p*T(:,i)' + T(:,i)*T(:,i)'*(T(:,i)'*p)/normT;
    Yres = Yres - T(:,i)*Q(:,i)';
    P(:,i) = p;
    %R{i} = U(:,i) * ((T(:,i)'*Kres*U(:,i))\T(:,i)')*Yres;
    R{i} = X'*U(:,i) * ((T(:,i)'*Kres*U(:,i))\T(:,i)')*Yres;
end
%R = U * ((T'*K*U)\T')*Y;
Ypred = X*R{nfactors};

end

