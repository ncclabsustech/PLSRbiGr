
% Prediction procedure by HOPLS T2T model (NIPS 2011)
% Input:
%   Xtest: test data with same tensor structure with training data.
%   model: model learned from training data
% Output:
%   Yp:   prediction of Ytest according to Xtest.
%



function pred = predict_test( Xtest, R, nfactor, thr )

%% preprocessing
%%
Wtpls = R ;

Xnew = Xtest;

for nfac = 1:nfactor
    
    Yp{nfac} = Xnew * Wtpls{ nfac };%
    
    assigned_class = hoplscfindclass( Yp{nfac}, thr);
    
    %% results for predict
    pred{nfac}.class_pred = assigned_class';
    pred{nfac}.yc = Yp{nfac};
end

