function M = BiSt_manifold( matrix_size )

    if length(matrix_size) > 2
        error('Bad usage of fixedrankfactory_tucker_preconditioned. Currently, only handles 3-order tensors.');
    end
    
    % matrix size
    m = matrix_size(1);
    n = matrix_size(2);
    r = min(m,n);
    

    M.name = @() sprintf('S x U x V  quotient SVD manifold of %d-by-%d matrix.', m, n);
    
    M.dim = @() m*r-r^2 + n*r-r^2 + r^2 ;
    
    
    % Choice of metric is motivated by symmetry and tuned to least-squares
    % cost function
    M.inner = @iproduct;
    function ip = iproduct(X, eta, zeta)
        ip =  trace(eta.U'*zeta.U) + trace(eta.V'*zeta.V) + trace(eta.S'*zeta.S);
    end
    M.norm = @(X, eta) sqrt(M.inner(X, eta, eta));
    
    M.dist = @(x, y) error('SVD manifold dist not implemented yet.');
    
    M.typicaldist = @() 10*n*r; % BM: To do  
    
    skew = @(X) .5*(X-X');
    symm = @(X) .5*(X+X');
    
    M.egrad2rgrad = @egrad2rgrad;
    function rgrad = egrad2rgrad(X, egrad)
        
        BU = 2*symm(X.U' * egrad.U);
        
        BV = 2*symm(X.V' * egrad.V);
        
        % The lyap solutions ensure that the Riemannian gradient rgrad 
        % is now on the tangent space. From the Riemannian submersion 
        % theory, it also belongs to the horizontal space. Therefore,
        % no need to further project it on the horizontal space.
        
        rgrad.U = egrad.U - X.U*BU;
        rgrad.V = egrad.V - X.V*BV;
        rgrad.S = egrad.S;
        
    end
    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 
 
 
 
    M.proj = @projection;
    function etaproj = projection(X, eta)
        
        % First, projection onto tangent space of total space
        BU = 2*symm(X.U'*eta.U );
        eta.U = eta.U - X.U*BU;
        
        BV = 2*symm(X.V'*eta.V);
        eta.V = eta.V - X.V*BV;
        eta.S = eta.S;
        
        
        % Project onto the horizontal space.
        % =================================================================
        BU = 2*skew(X.U'*eta.U);
        etaproj.U = eta.U - X.U*BU;
        
        BV = 2*skew(X.V'*eta.V);
        etaproj.V = eta.V - X.V*BV;
        etaproj.S = eta.S;
        
    end
    
    
    
    M.tangent = M.proj;
    M.tangent2ambient = @(X, eta) eta;
    
    M.retr = @retraction;
    function Y = retraction(X, eta, t)
        if nargin < 3
            t = 1.0;
        end
        
        Y.U = uf((X.U + t*eta.U)); % U factor of Polar factorization
        Y.V = uf((X.V + t*eta.V));
        Y.S = (X.S + t*eta.S);
    end
    
    M.exp = @exponential;
    function Y = exponential(X, eta, t)
        if nargin < 3
            t = 1.0;
        end
        Y = retraction(X, eta, t);
        warning('manopt:fixedrankfactory_tucker_preconditioned:exp', ...
            ['Exponential for fixed rank ' ...
            'Tucker manifold not implemented yet. Used retraction instead.']);
    end
    
    M.hash = @(X) ['z' hashmd5([sum(X.U(:)) ; sum(X.V(:)) ; sum(X.S(:))])]; % Efficient, suggested by Bart Vandereycken.
    % M.hash = @(X) ['z' hashmd5([X.U1(:); X.U2(:)])];
    
    M.rand = @random;
    function X = random()
        %         % Random generator on the total space
        %         % FactorsU2, and U3 are on Stiefel manifolds, hence we reuse
        %         % their random generator.
        %         stiefelm = stiefelfactory(n2, r2);
        %         stiefeln = stiefelfactory(n3, r3);
        %
        %         X.U2 = stiefelm.rand();
        %         X.U3 = stiefeln.rand();
        %
        %         % Random initialization: generalization of randn(r1, r1 = r2) in the
        %         % matrix case.
        %         X.G = randn(n,r2,r3);
        
        
        %  Random generator on the fixed-rank space from a uniform distribution on [0, 1].
        %[U, S, V] = svd(rand(m, n), 'econ');
        [U, S, V] = svds(rand(m, n), r);
        X.U = U;
        X.V = V;
        X.S = S;
    
        % Compute some terms that are used subsequently.
        
    end
    

    M.randvec = @randomvec;
    function eta = randomvec(X)
        % A random vector on the horizontal space
        eta.U = randn(m, r);
        eta.V = randn(n, r);
        eta.S = diag(diag(rand(r,r)));
        eta = projection(X, eta);
        nrm = M.norm(X, eta);
        eta.U = eta.U / nrm;
        eta.V = eta.V / nrm;
        eta.S = eta.S / nrm;
    end

    M.lincomb = @lincomb;
    
    M.zerovec = @(X) struct('U', zeros(m, r), 'V', zeros(n, r), 'S', zeros(r, r));    
    M.transp = @(x1, x2, d) projection(x2, d);
    
    % vec and mat are not isometries, because of the scaled metric.
    M.vec = @(X, U) [U.U(:); U.V(:); U.S(:)];
    M.vecmatareisometries = @() false;
    
end

% Linear combination of tangent vectors
function d = lincomb(X, a1, d1, a2, d2) %#ok<INUSL>
    
    if nargin == 3
        d.U = a1*d1.U;
        d.V = a1*d1.V;
        d.S = a1*d1.S;
    elseif nargin == 5
        d.U = a1*d1.U + a2*d2.U;
        d.V = a1*d1.V + a2*d2.V;
        d.S = a1*d1.S + a2*d2.S;
    else
        error('Bad use of fixedrankfactory_tucker_preconditioned.lincomb.');
    end
    
end

function U = uf(A) % U factor of Polar factorization of a tall matrix A.
    [L, unused, R] = svd(A, 0); %#ok
    U = L*R';
end


