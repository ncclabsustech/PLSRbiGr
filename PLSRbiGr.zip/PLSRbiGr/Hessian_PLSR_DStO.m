function [W] = Hessian_PLSR_DStO(X0,Y0, p)

n = size(X0,2);
Cxy = X0'*Y0;
C = Cxy *Cxy';
W = orth(rand(n, p))/100;

problem.M  = stiefelfactory(n, p);

function store = prepare(W, C, store)
    %Obj = diag(diag(W'*C*W));
    Obj = W'*C*W;
    store.C = Obj;
end

problem.cost = @cost;
function [f, store] = cost(W, store)
    store = prepare(W, C, store);
    f = -trace(store.C);
end

problem.egrad = @egrad;
function [G, store] = egrad(W, store)
    store = prepare(W, C, store);
    egrad = - 2*C*W;
    store.egrad = egrad;
    G = problem.M.egrad2rgrad(W, egrad);
end

problem.hess = @hess;
function [H, store] = hess(W, eta, store)
    store = prepare(W, C, store);
    hess = - 2*C*eta;
    H = problem.M.ehess2rhess(W, store.egrad, hess, eta);
end



%checkgradient(problem);% pause;
%checkhessian(problem); pause;
 
        options.maxiter = 200;
        options.maxinner = 30;
        options.maxtime = inf;
        options.tolgradnorm = 1e-5;
        options.Delta_bar = problem.M.typicaldist();
        % Minimize the cost function using Riemannian trust-regions
        W = trustregions(problem, [], options);   
    
end