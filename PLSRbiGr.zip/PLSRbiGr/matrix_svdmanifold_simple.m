
function Xtr = matrix_svdmanifold_simple(A, p)
% =========================================================================
% 注意 张量A 的一次模与core_dims(1) 相同， 代表样本个数, 

% Given partial observation of a low rank tensor, attempts to complete it.
%
% function low_rank_tensor_completion()
%
% This example demonstrates how to use the geometry factory for the
% quotient manifold of fixed-rank tensors, 
% fixedrankfactory_tucker_preconditioned.
%
% This geometry is described in the technical report
% "Riemannian preconditioning for tensor completion"
% Hiroyuki Kasai and Bamdev Mishra, arXiv:1506.02159, 2015.
%
% This can be a starting point for many optimization problems of the form:
%
% minimize f(X) such that rank(X) = [r1 r2 r3], size(X) = [n1, n2, n3].
%
% Input:  None. This example file generates random data.
% 
% Output: None.
%
% Please cite the Manopt paper as well as the research paper:
%     @Techreport{kasai2015,
%       Title   = {{R}iemannian preconditioning for tensor completion},
%       Author  = {Kasai, H. and Mishra, B.},
%       Journal = {Arxiv preprint arXiv:1506.02159},
%       Year    = {2015}
%     }

% This file is part of Manopt and is copyrighted. See the license file.
% 
% Main authors: Hiroyuki Kasai and Bamdev Mishra, June 16, 2015.
% Contributors:
% 
% Change log:
% 
    

    % Random data generation with pseudo-random numbers from a 
    % uniform distribution on [0, 1].
    % First, choose the size of the problem.
    % We will complete a tensor of size n1-by-n2-by-n3 of rank (r1, r2, r3):  
    m = size(A,1);
    n = size(A,2);
    matrix_size = [m n]; % m > n ;
    
    % Generate a random mask P for observed entries: P(i, j, k) = 1 if the entry
    % (i, j, k) of A is observed, and 0 otherwise.    
    % Observation ratio
   
    % Hence, we know the nonzero entries in PA:
    
    
    % Pick the manifold of tensors of size n1-by-n2-by-n3 of rank (r1, r2, r3).
    problem.M = svdmanifold( matrix_size );
    X.U = orth(rand(m, p));
    X.V = orth(rand(n, p));
    X.S = diag(diag(rand(p, p)));
    X = X.U*X.S*X.V';
    
    
    % Define the problem cost function. The input X is a structure with
    % fields U1, U2, U3, G representing a rank (r1,r2,r3) tensor.
    % f(X) = 1/2 * || P.*(X - A) ||^2
    problem.cost = @cost;
    function f = cost(X)
        %f = -.5*trace(X'*X + A'*A - 2*X'*A);
        f = - .5*trace(X.U*X.S*X.S'*X.U' + A*A' - 2*X.U*X.S*X.V'*A');
    end


    
    
    % Define the Euclidean gradient of the cost function, that is, the
    % gradient of f(X) seen as a standard function of X.
    % nabla f(X) = P.*(X-A)
    % We only need to give the Euclidean gradient. Manopt converts it
    % internally to the Riemannian counterpart.
    problem.egrad =  @egrad;
    function [g, store] = egrad(X, store)

        % BM: computation of S, S2, and S3

        g.U = - X.U * X.S * X.S' + A * X.V * X.S';
        g.V = - X.V' * X.S' * X.S + A' * X.U * X.S;
        g.S = - X.S * X.V' + X.U' * A * X.V; 
        store.g = g;
        %G = problem.M.egrad2rgrad(X, g);
    end

    problem.ehess =  @ehess;
    function [h, store] = ehess(X, eta, store)

        % BM: computation of S, S2, and S3

        h.U = - eta.U * X.S * X.S' + A * X.V * X.S';
        h.V = - eta.V' * X.S' * X.S + A' * X.U * X.S;
        h.S = - eta.S * X.V' + X.U' * A * X.V;  
        store.h = h;
        %H = problem.M.ehess2rhess(X, store.g, h, eta);
    end
    % Define the Euclidean Hessian of the cost at X, along eta, where eta is
    % represented as a tangent vector: a structure with fields U1, U2, U3, G.
    % This is the directional derivative of nabla f(X) at X along Xdot:
    % nabla^2 f(X)[Xdot] = P.*Xdot
    % We only need to give the Euclidean Hessian. Manopt converts it
    % internally to the Riemannian counterpart.
    % Solve.
        % options
        options.maxiter = 500;
        options.maxinner = 30;
        options.maxtime = inf;
        options.tolgradnorm = 1e-5;
        options.Delta_bar = problem.M.typicaldist();
        % Minimize the cost function using Riemannian trust-regions
        %Xtr = conjugategradient(problem, [], options);
        Xtr = trustregions(problem, [], options);     
% =========================================================================
   
    
end



