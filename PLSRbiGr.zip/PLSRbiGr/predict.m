% =========================================================================
function pred = predict( test, model )
            mean_test = mean(test,1);
            Xnew = bsxfun(@minus, test, mean_test);
            nfactors = model.nfactors;
            R = model.R;
    % =====================================================================       
    for nfac = 1:nfactors
        Yp{nfac} = Xnew * R{ nfac };%
       %% post processing for Y
        mean_Yp = mean(Yp{nfac},1);
        Yp{nfac} = bsxfun(@minus, Yp{nfac}, mean_Yp);
       %%
        assigned_class = hoplscfindclass( Yp{nfac}, model.thr);
       %% results for predict
        pred{nfac}.class_pred = assigned_class';
        pred{nfac}.yc = Yp{nfac};
    end

end


