function Xtr = matrix_svdmanifold(A)
% =========================================================================
% ע�� ����A ��һ��ģ��core_dims(1) ��ͬ�� ������������, 

% Given partial observation of a low rank tensor, attempts to complete it.
%
% function low_rank_tensor_completion()
%
% This example demonstrates how to use the geometry factory for the
% quotient manifold of fixed-rank tensors, 
% fixedrankfactory_tucker_preconditioned.
%
% This geometry is described in the technical report
% "Riemannian preconditioning for tensor completion"
% Hiroyuki Kasai and Bamdev Mishra, arXiv:1506.02159, 2015.
%
% This can be a starting point for many optimization problems of the form:
%
% minimize f(X) such that rank(X) = [r1 r2 r3], size(X) = [n1, n2, n3].
%
% Input:  None. This example file generates random data.
% 
% Output: None.
%
% Please cite the Manopt paper as well as the research paper:
%     @Techreport{kasai2015,
%       Title   = {{R}iemannian preconditioning for tensor completion},
%       Author  = {Kasai, H. and Mishra, B.},
%       Journal = {Arxiv preprint arXiv:1506.02159},
%       Year    = {2015}
%     }

% This file is part of Manopt and is copyrighted. See the license file.
% 
% Main authors: Hiroyuki Kasai and Bamdev Mishra, June 16, 2015.
% Contributors:
% 
% Change log:
% 
    

    % Random data generation with pseudo-random numbers from a 
    % uniform distribution on [0, 1].
    % First, choose the size of the problem.
    % We will complete a tensor of size n1-by-n2-by-n3 of rank (r1, r2, r3):  
    m = size(A, 1);
    n = size(A, 2);
    matrix_size = [m n]; % m > n ;
    
    % Generate a random mask P for observed entries: P(i, j, k) = 1 if the entry
    % (i, j, k) of A is observed, and 0 otherwise.    
    % Observation ratio
   
    % Hence, we know the nonzero entries in PA:
    
    
    % Pick the manifold of tensors of size n1-by-n2-by-n3 of rank (r1, r2, r3).
    problem.M = svdmanifold( matrix_size );
    %problem.M = svdmanifold_noscaling( matrix_size );
    
    
    problem.cost = @cost;
    function f = cost(X)
        Xmu = svd2matrix(X);
        Diff = Xmu - A;
        f = .5*norm(Diff , 'fro')^2;
    end


    
    
    % Define the Euclidean gradient of the cost function, that is, the
    % gradient of f(X) seen as a standard function of X.
    % nabla f(X) = P.*(X-A)
    % We only need to give the Euclidean gradient. Manopt converts it
    % internally to the Riemannian counterpart.
    problem.egrad =  @egrad;
    function [g] = egrad(X)
        Xmu = svd2matrix(X);
        Diff = Xmu - A;     

        % BM: computation of S, S2, and S3

        g.U = Diff * X.V * X.S';
        g.V = Diff' * X.U * X.S;
        g.S = X.U'*Diff*X.V;  
    end
    
    % Define the Euclidean Hessian of the cost at X, along eta, where eta is
    % represented as a tangent vector: a structure with fields U1, U2, U3, G.
    % This is the directional derivative of nabla f(X) at X along Xdot:
    % nabla^2 f(X)[Xdot] = P.*Xdot
    % We only need to give the Euclidean Hessian. Manopt converts it
    % internally to the Riemannian counterpart.
    
    % options
    options.maxiter = 500;
    options.maxinner = 30;
    options.maxtime = inf;
    options.tolgradnorm = 1e-5;     
    % Minimize the cost function using Riemannian trust-regions
    Xtr = conjugategradient(problem, [], options);
    
    
end





