clear all
clc

addpath( genpath(pwd) );
Dataset_name = {'COIL20'};
%==========================================================================
nfactors = 20;
TFBS_name = Dataset_name{ 1 };
fprintf('Dataset Name:   %s\n', TFBS_name);
fprintf('Loading   ...');
load( TFBS_name );% loading dataset
cross_num = 4;
cros = 2;
indices = kFoldCV( Y, cross_num );% ���飬���뱣֤ÿһfold�а�������
test_indx = (indices == cros);
train_indx = ~test_indx;
train = X( train_indx, :);                     %===================%
train_label = Y( train_indx );                     %      ѡ��ѵ����    %
%                                                  %===================%
test = X( test_indx, :);                       %===================%
test_label = Y(test_indx);                         %     ѡ����Լ�     %
% =========================================================================
% ================================== main_kernelPLS =======================
y_label = binarize_y( train_label );
% ȥ���Ļ� =====================================================
% =============================================================
            mean_train = mean(train,1);
            train = bsxfun(@minus, train, mean_train);
            mean_label = mean(y_label,1);
            y_label = bsxfun(@minus, y_label, mean_label);
            % =============================================================
            alpha = 1;                             %  parameter setting  %
            coef = 0.1;                            %---------------------%
            Kxx = kernel( train, train, 'polynomial', alpha, coef );                 %  polynomial kernel
            [T, W, Q] = kernelPLS( Kxx, y_label, nfactors );
            % =============================================================
            for i = 1:nfactors
                Wstar{i} = W(:,1:i) * pinv(T(:,1:i)'*Kxx(i,i)*W(:, 1:i) + diag(rand(i,1))*eps);
                R{ i } = Wstar{ i } * Q(:,1:i )';
            end
            % =============================================================
            Ypred = Kxx * R{nfactors};
            if abs(min( Ypred(:,1) ) - max( Ypred(:,1) ))<eps | abs(min( Ypred(:,2) ) - max( Ypred(:,2) ))<eps
                disp('wait');
            end
            resthr = hoplscfindthr( Ypred, train_label );
            % =============================================================
            % =============================================================
            model.yc = Ypred;
            model.thr = resthr.class_thr;
            model.Wstar = Wstar;
            model.R = R;
            model.nfactors = nfactors;
            % =============================================================
            % ============= predict_KernelPLS =============================
            mean_test = mean(test,1);
            Xnew = bsxfun(@minus, test, mean_test);
            nfactors = model.nfactors;
            R = model.R;
    % =====================================================================
    alpha = 1;                             %  parameter setting  %
    coef = 0.1;                            %---------------------%
    
    Ktt = kernel( Xnew, Xnew, 'polynomial', alpha, coef );
    for nfac = 1:nfactors
        Yp{nfac} = Ktt' * R{ nfac };%
       %% post processing for Y
        mean_Yp = mean(Yp{nfac},1);
        Yp{nfac} = bsxfun(@minus, Yp{nfac}, mean_Yp);
       %%
        assigned_class = hoplscfindclass( Yp{nfac}, model.thr);
       %% results for predict
        pred{nfac}.class_pred = assigned_class';
        pred{nfac}.yc = Yp{nfac};
    end
            
            
            
            
            
            
            
            
            
            
            
            
            
            



















